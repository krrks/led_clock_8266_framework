#! internal metadata — ignored by release notes

Patch 002 — Display mirror + info column fixes

- Fix: left-right mirror in LEDMatrixLayout.h (physical wiring from bottom-right)
- Fix: info bars now drawn as vertical columns on right side (col 26/28/30)
- Fix: digit start column set to 0 (no offset)
- Fix: default brightness = 5, default year = 2026
- Feat: detailed Serial Monitor output throughout boot and loop
- Feat: README.md rewritten with full layout diagram, config table, troubleshooting
