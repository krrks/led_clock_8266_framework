// DisplayManager.h
#ifndef DISPLAYMANAGER_H
#define DISPLAYMANAGER_H

#include <Arduino.h>
#include <FastLED.h>
#include "PinDefinitions.h"
#include "LEDMatrixLayout.h"
#include "ClockFace.h"
#include "InfoColumns.h"

class DisplayManager {
public:
    DisplayManager();

    void begin();
    void setBrightness(uint8_t level);

    void render(int hour, int minute,
                int weekday, int day,
                uint32_t weatherColor);

    void showRecovery();
    void scrollTick();
    void clear();

private:
    CRGB _matrix[MATRIX_HEIGHT][MATRIX_WIDTH];
    CRGB _leds[NUM_LEDS];

    bool          _recovery;
    int           _scrollOffset;
    unsigned long _lastScroll;

    static const uint8_t BRIGHTNESS_TABLE[3];

    void _clearMatrix();
    void _push();
};

#endif // DISPLAYMANAGER_H
