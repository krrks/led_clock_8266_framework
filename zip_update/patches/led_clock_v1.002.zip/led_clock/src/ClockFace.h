// ClockFace.h
#ifndef CLOCKFACE_H
#define CLOCKFACE_H

#include <Arduino.h>
#include <FastLED.h>
#include "LEDMatrixLayout.h"
#include "FontData.h"

class ClockFace {
public:
    static void render(CRGB matrix[MATRIX_HEIGHT][MATRIX_WIDTH],
                       int hour, int minute,
                       CRGB digitColor, CRGB colonColor);

    static void renderScroll(CRGB matrix[MATRIX_HEIGHT][MATRIX_WIDTH],
                              int offset, CRGB color);

    static int scrollTextWidth();

private:
    static void _renderChar(CRGB matrix[MATRIX_HEIGHT][MATRIX_WIDTH],
                             int startCol, char c, CRGB color);
};

#endif // CLOCKFACE_H
