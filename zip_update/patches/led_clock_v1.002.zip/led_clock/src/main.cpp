// main.cpp — LED Matrix Clock
// Wemos D1 Mini (ESP8266) + 32×8 WS2812B matrix
//
// Built against maakbaas/esp8266-iot-framework (lib_dep).
// Generated headers (config.h, dash.h) come from the framework's
// preBuild scripts driven by our gui/js/configuration.json and
// gui/js/dashboard.json.

#include <Arduino.h>
#include "LittleFS.h"
#include <FastLED.h>
#include <ArduinoJson.h>          // v6
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include <time.h>

// Framework singletons
#include "WiFiManager.h"
#include "webServer.h"
#include "updater.h"
#include "configManager.h"
#include "timeSync.h"
#include "dashboard.h"

// Project headers
#include "PinDefinitions.h"
#include "LEDMatrixLayout.h"
#include "FontData.h"
#include "ButtonHandler.h"

// ─────────────────────────────────────────────────────────────────────
// Compile-time constants
// ─────────────────────────────────────────────────────────────────────
#define DEFAULT_BRIGHTNESS    5UL       // low default (~2 % of 255)
#define BOOT_WINDOW_MS     3000UL       // silent boot window
#define LONG_PRESS_MS      1000UL       // triggers recovery
#define VERY_LONG_PRESS_MS 5000UL       // triggers reboot
#define IDLE_TIMEOUT_MS   30000UL       // inactivity → idle mode
#define ACTIVE_REFRESH_MS  1000UL       // display update when active
#define IDLE_REFRESH_MS   30000UL       // display update when idle
#define SCROLL_FRAME_MS     80UL        // ~12 fps scroll
#define NTP_INTERVAL_MS  3600000UL      // NTP re-sync interval (1 h)
#define WEATHER_INT_MS   3600000UL      // weather re-fetch interval (1 h)
#define WIFI_RETRY_MS    3600000UL      // AP-mode WiFi retry interval
#define DASH_INT_MS        5000         // dashboard WebSocket cadence (int)
#define LED_BLINK_BOOT      100UL
#define LED_BLINK_REC      1000UL

// Display column layout (cols 0-31):
//   [0-4]   H tens digit
//   [5]     space
//   [6-10]  H units digit
//   [11]    space
//   [12]    colon
//   [13]    space
//   [14-18] M tens digit
//   [19]    space
//   [20-24] M units digit
//   [25]    gap
//   [26]    DATE column   (1 px/week-of-month, white, bottom-up)
//   [27]    gap
//   [28]    WEEKDAY column (1-7 px Mon-Sun, cyan/orange, bottom-up)
//   [29]    gap
//   [30]    WEATHER column (4 px, color-coded, bottom-up)
//   [31]    trailing pad

// RTC memory: survives software reset, lost on power-cycle.
#define RTC_MAGIC 0xC10CFA11UL
struct RTCData {
    uint32_t magic;
    uint32_t enterRecovery; // 1 = enter recovery on next boot
};

// ─────────────────────────────────────────────────────────────────────
// Globals
// ─────────────────────────────────────────────────────────────────────
CRGB        leds[NUM_LEDS];
uint32_t    displayMatrix[MATRIX_HEIGHT][MATRIX_WIDTH];
ButtonHandler button(BUTTON_PIN);

bool inRecovery       = false;
bool ntpSynced        = false;
bool longPressHandled = false;

// Weather state
int16_t  weatherCode      = 800;
float    weatherTemp      = 25.0f;
char     weatherDesc[32]  = "Clear";
int      weatherFailCount = 0;

// Manual time fallback
struct tm manualTm   = {};
uint32_t  manualBase = 0;   // millis() snapshot when manual time was set

// Timing bookmarks
unsigned long lastDisplayRefresh = 0;
unsigned long lastNtpSync        = 0;
unsigned long lastWeatherSync    = 0;
unsigned long lastDashUpdate     = 0;
unsigned long lastUserActivity   = 0;
unsigned long lastLedBlink       = 0;
unsigned long lastWifiRetry      = 0;
bool          ledBlinkState      = false;

// Scroll state (recovery text)
static int           scrollOff  = 0;
static unsigned long lastScroll = 0;

// ─────────────────────────────────────────────────────────────────────
// Colour helpers
// ─────────────────────────────────────────────────────────────────────
static inline uint32_t rgb(uint8_t r, uint8_t g, uint8_t b) {
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | b;
}

const uint32_t C_WHITE  = rgb(255, 255, 255);
const uint32_t C_ORANGE = rgb(255, 165,   0);
const uint32_t C_CYAN   = rgb(  0, 200, 200);

static uint32_t weatherColor(int16_t code) {
    if (code >= 200 && code < 300) return rgb(128,   0, 128); // thunderstorm: purple
    if (code >= 300 && code < 400) return rgb(  0, 128, 255); // drizzle: light blue
    if (code >= 500 && code < 600) return rgb(  0,   0, 255); // rain: blue
    if (code >= 600 && code < 700) return rgb(  0, 255, 255); // snow: cyan
    if (code >= 700 && code < 800) return rgb( 80,  80,  80); // fog/mist: dim grey
    if (code == 800)               return rgb(255, 200,   0); // clear sky: yellow
    if (code >= 801 && code <= 802) return rgb(180, 180,   0); // few clouds: pale yellow
    if (code >= 803 && code <= 804) return rgb(120, 120, 120); // overcast: grey
    if (code > 0)                  return rgb(180, 180, 180); // other clouds
    return rgb( 60,  60,  60);                                 // no data: dim grey
}

// ─────────────────────────────────────────────────────────────────────
// Display primitives
// ─────────────────────────────────────────────────────────────────────
static void clearDisplay() {
    memset(displayMatrix, 0, sizeof(displayMatrix));
}

// Draw one character at pixel column x; returns glyph width consumed.
static int drawChar(char c, int x, uint32_t color) {
    const uint8_t* fd = getCharFontData(c);
    uint8_t w = getCharWidth(c);
    if (!fd) return (int)w;
    for (uint8_t col = 0; col < w; col++) {
        int px = x + (int)col;
        if (px < 0 || px >= (int)MATRIX_WIDTH) continue;
        uint8_t bits = fd[col];
        for (uint8_t row = 0; row < DIGIT_HEIGHT; row++) {
            if ((bits >> row) & 1)
                displayMatrix[row][px] = color;
        }
    }
    return (int)w;
}

// Scrolling text for recovery mode.
static void drawScrollText(const char* txt, uint32_t color) {
    clearDisplay();

    // Measure total pixel width (glyph width + 1 px gap each)
    int totalW = 0;
    for (int i = 0; txt[i]; i++) totalW += (int)getCharWidth(txt[i]) + 1;

    int x = (int)MATRIX_WIDTH - scrollOff;
    for (int i = 0; txt[i]; i++) {
        x += drawChar(txt[i], x, color) + 1;
    }

    if (millis() - lastScroll >= SCROLL_FRAME_MS) {
        lastScroll = millis();
        if (++scrollOff >= totalW + (int)MATRIX_WIDTH)
            scrollOff = 0;
    }
}

// Draw HH:MM into display columns 0–24.
// Layout: [0-4] H_tens  [5] space  [6-10] H_units  [11] space
//         [12] colon  [13] space  [14-18] M_tens  [19] space  [20-24] M_units
static void drawTime(int hour, int minute, uint32_t color) {
    int x = 0;
    x += drawChar((char)('0' + hour   / 10), x, color); x++; // col 0-4, skip 5
    x += drawChar((char)('0' + hour   % 10), x, color); x++; // col 6-10, skip 11
    x += drawChar(':',                        x, color); x++; // col 12, skip 13
    x += drawChar((char)('0' + minute / 10), x, color); x++; // col 14-18, skip 19
         drawChar((char)('0' + minute % 10), x, color);       // col 20-24
}

// Draw the three vertical info bar columns at the right side of the matrix.
//
//   col 26 — DATE column:    1 pixel per week-of-month (1–5), white
//   col 28 — WEEKDAY column: 1–7 pixels (Mon–Sun), cyan weekdays / orange weekends
//   col 30 — WEATHER column: always 4 pixels, colour encodes OWM condition
//
// All bars are lit bottom-to-top (row 7 = bottom = first lit pixel).
static void drawInfoBars(int mday, int wday) {
    // DATE column (col 26): week 1 = 1 px, week 2 = 2 px ... week 5 = 5 px
    int weekOfMonth = (mday - 1) / 7 + 1;
    weekOfMonth = constrain(weekOfMonth, 1, 5);
    for (int i = 0; i < weekOfMonth; i++)
        displayMatrix[MATRIX_HEIGHT - 1 - i][26] = C_WHITE;

    // WEEKDAY column (col 28): Mon=1 px .. Sun=7 px
    wday = constrain(wday, 1, 7);
    uint32_t wc = (wday >= 6) ? C_ORANGE : C_CYAN;
    for (int i = 0; i < wday; i++)
        displayMatrix[MATRIX_HEIGHT - 1 - i][28] = wc;

    // WEATHER column (col 30): 4 pixels, colour = OWM condition code
    uint32_t wx = weatherColor(weatherCode);
    for (int i = 0; i < 4; i++)
        displayMatrix[MATRIX_HEIGHT - 1 - i][30] = wx;
}

// Flush displayMatrix → FastLED LEDs → hardware.
static void flushDisplay() {
    uint32_t buf[NUM_LEDS];
    convertToSnakeOrder(displayMatrix, buf);
    for (int i = 0; i < NUM_LEDS; i++) {
        leds[i].r = (uint8_t)((buf[i] >> 16) & 0xFF);
        leds[i].g = (uint8_t)((buf[i] >>  8) & 0xFF);
        leds[i].b = (uint8_t)( buf[i]        & 0xFF);
    }
    FastLED.show();
}

// ─────────────────────────────────────────────────────────────────────
// Time helper
// ─────────────────────────────────────────────────────────────────────
static struct tm* getTime() {
    if (ntpSynced) {
        time_t now = time(nullptr);
        return localtime(&now);
    }
    // millis()-tracked manual fallback
    time_t t = mktime(&manualTm) + (long)((millis() - manualBase) / 1000UL);
    return localtime(&t);
}

// ─────────────────────────────────────────────────────────────────────
// Weather fetch (plain HTTP, OpenWeatherMap free tier)
// ─────────────────────────────────────────────────────────────────────
static void fetchWeather() {
    if (WiFiManager.isCaptivePortal()) {
        Serial.println("[Weather] Skipped — no WiFi (AP mode active)");
        return;
    }
    if (strlen(configManager.data.weatherApiKey) < 8) {
        Serial.println("[Weather] Skipped — API key not configured (< 8 chars)");
        return;
    }
    if (strlen(configManager.data.weatherCity) == 0) {
        Serial.println("[Weather] Skipped — city not configured");
        return;
    }

    Serial.printf("[Weather] Fetching for city: %s\n", configManager.data.weatherCity);

    WiFiClient client;
    HTTPClient http;

    String url = F("http://api.openweathermap.org/data/2.5/weather?q=");
    url += configManager.data.weatherCity;
    url += F("&appid=");
    url += configManager.data.weatherApiKey;
    url += F("&units=metric");

    if (http.begin(client, url)) {
        int httpCode = http.GET();
        Serial.printf("[Weather] HTTP response code: %d\n", httpCode);
        if (httpCode == HTTP_CODE_OK) {
            StaticJsonDocument<1024> doc;
            DeserializationError err = deserializeJson(doc, http.getStream());
            if (!err) {
                weatherCode = (int16_t)(doc["weather"][0]["id"]    | 800);
                weatherTemp =           doc["main"]["temp"]         | 25.0f;
                strlcpy(weatherDesc,
                        doc["weather"][0]["description"] | "Unknown",
                        sizeof(weatherDesc));
                weatherFailCount = 0;
                Serial.printf("[Weather] OK  code=%d  %.1f°C  %s\n",
                              weatherCode, weatherTemp, weatherDesc);
            } else {
                weatherFailCount++;
                Serial.printf("[Weather] JSON parse error: %s  (fail #%d)\n",
                              err.c_str(), weatherFailCount);
            }
        } else {
            weatherFailCount++;
            Serial.printf("[Weather] HTTP error: %d  (fail #%d)\n",
                          httpCode, weatherFailCount);
        }
        http.end();
    } else {
        weatherFailCount++;
        Serial.printf("[Weather] http.begin() failed  (fail #%d)\n", weatherFailCount);
    }
}

// ─────────────────────────────────────────────────────────────────────
// Dashboard data fill (struct generated from dashboard.json)
// ─────────────────────────────────────────────────────────────────────
static void updateDashboard() {
    struct tm* t = getTime();
    if (!t) return;

    // currentTime  char[9]
    char buf[16];
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d",
             t->tm_hour, t->tm_min, t->tm_sec);
    strlcpy(dash.data.currentTime, buf, sizeof(dash.data.currentTime));

    // currentDate  char[12]
    snprintf(buf, sizeof(buf), "%04d-%02d-%02d",
             t->tm_year + 1900, t->tm_mon + 1, t->tm_mday);
    strlcpy(dash.data.currentDate, buf, sizeof(dash.data.currentDate));

    // weekday  char[10]
    static const char* wd[] = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
    strlcpy(dash.data.weekday, wd[t->tm_wday], sizeof(dash.data.weekday));

    dash.data.ntpSynced   = ntpSynced;
    dash.data.temperature = weatherTemp;
    dash.data.weatherCode = (uint16_t)weatherCode;
    strlcpy(dash.data.weatherDesc, weatherDesc, sizeof(dash.data.weatherDesc));
    dash.data.freeHeap    = (uint32_t)ESP.getFreeHeap();
    dash.data.uptime      = (uint32_t)(millis() / 1000UL);
    dash.data.inRecovery  = inRecovery;
}

// ─────────────────────────────────────────────────────────────────────
// Status LED
// ─────────────────────────────────────────────────────────────────────
static void blinkLed(unsigned long rateMs) {
    if (millis() - lastLedBlink >= rateMs) {
        lastLedBlink  = millis();
        ledBlinkState = !ledBlinkState;
        digitalWrite(STATUS_LED_PIN, ledBlinkState ? LOW : HIGH); // active-LOW
    }
}

static void updateStatusLed() {
    if (inRecovery) {
        blinkLed(LED_BLINK_REC);
    } else {
        digitalWrite(STATUS_LED_PIN, HIGH); // always OFF in normal mode
    }
}

// ─────────────────────────────────────────────────────────────────────
// setup()
// ─────────────────────────────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    delay(200);

    Serial.println();
    Serial.println(F("========================================"));
    Serial.println(F("  LED Matrix Clock — Wemos D1 Mini"));
    Serial.printf ("  SDK: %s  Core: %s\n",
                   ESP.getSdkVersion(), ESP.getCoreVersion().c_str());
    Serial.printf ("  Free heap: %u bytes\n", ESP.getFreeHeap());
    Serial.println(F("========================================"));

    // Hardware init
    pinMode(STATUS_LED_PIN, OUTPUT);
    digitalWrite(STATUS_LED_PIN, LOW); // ON during boot to show we're alive

    button.begin();
    Serial.println(F("[Init] Button initialised on GPIO5"));

    LittleFS.begin();
    Serial.println(F("[Init] LittleFS mounted"));

    configManager.begin();
    Serial.printf("[Init] Config loaded — city=%s tz=%s brightness=%u\n",
                  configManager.data.weatherCity,
                  configManager.data.timezone,
                  configManager.data.brightness);

    // LED matrix
    FastLED.addLeds<WS2812B, LED_MATRIX_PIN, GRB>(leds, NUM_LEDS);
    uint8_t brt = configManager.data.brightness;
    if (brt == 0) brt = (uint8_t)DEFAULT_BRIGHTNESS;
    FastLED.setBrightness(brt);
    FastLED.clear(true);
    Serial.printf("[Init] FastLED — %d LEDs on GPIO4, brightness=%u\n",
                  NUM_LEDS, brt);

    // Apply brightness whenever config is saved from the web UI
    configManager.setConfigSaveCallback([]() {
        FastLED.setBrightness(configManager.data.brightness);
        lastUserActivity = millis();
        Serial.printf("[Config] Saved via web — brightness=%u city=%s\n",
                      configManager.data.brightness,
                      configManager.data.weatherCity);
    });

    // ── Recovery detection ────────────────────────────────────────────

    // 1. Crash / watchdog reset
    String reason     = ESP.getResetReason();
    bool   crashReset = (reason == "Exception" ||
                         reason.indexOf("Watchdog") >= 0);
    Serial.printf("[Boot] Reset reason: %s  (crashFlag=%d)\n",
                  reason.c_str(), crashReset);

    // 2. Runtime long-press stored in RTC memory
    RTCData rtc = {};
    bool rtcRecovery = false;
    if (ESP.rtcUserMemoryRead(0,
            reinterpret_cast<uint32_t*>(&rtc), sizeof(rtc)))
    {
        if (rtc.magic == RTC_MAGIC && rtc.enterRecovery == 1) {
            rtcRecovery       = true;
            rtc.enterRecovery = 0;
            ESP.rtcUserMemoryWrite(0,
                reinterpret_cast<uint32_t*>(&rtc), sizeof(rtc));
            Serial.println(F("[Boot] RTC recovery flag was set — clearing"));
        }
    }

    // 3. Boot-window button long-press (silent 3 s window, LED fast-blinks)
    bool bootLongPress = false;
    unsigned long bootStart = millis();
    Serial.println(F("[Boot] Entering 3 s boot window (hold button for recovery)..."));
    while (millis() - bootStart < BOOT_WINDOW_MS) {
        button.update();
        if (button.isPressed() &&
            button.getPressDuration() >= LONG_PRESS_MS) {
            bootLongPress = true;
            Serial.println(F("[Boot] Long-press detected in boot window!"));
            break;
        }
        blinkLed(LED_BLINK_BOOT);
        delay(10);
        yield();
    }

    inRecovery = crashReset || rtcRecovery || bootLongPress;
    Serial.printf("[Boot] crash=%d rtcFlag=%d bootBtn=%d  → recovery=%d\n",
                  crashReset, rtcRecovery, bootLongPress, inRecovery);

    // Framework web server + dashboard
    GUI.begin();
    dash.begin(DASH_INT_MS);
    Serial.println(F("[Init] Web GUI started"));

    // WiFi — use "LED-CLOCK" AP name always (recovery or not)
    const char* apName = "LED-CLOCK";
    Serial.printf("[WiFi] Connecting (timeout 15 s), AP name if needed: %s\n", apName);
    WiFiManager.begin(apName, 15000);

    if (WiFiManager.isCaptivePortal()) {
        Serial.println(F("[WiFi] No saved network found — AP mode active at 192.168.4.1"));
    } else {
        Serial.printf("[WiFi] Connected to %s\n", WiFiManager.SSID().c_str());
    }

    // NTP + timezone (skip in recovery — web GUI is available either way)
    if (!inRecovery) {
        const char* tz = (strlen(configManager.data.timezone) > 0)
                         ? configManager.data.timezone
                         : "HKT-8";
        Serial.printf("[NTP] Setting timezone: %s\n", tz);
        timeSync.begin(tz);

        Serial.println(F("[NTP] Waiting for sync (10 s)..."));
        if (timeSync.waitForSyncResult(10000) == 0) {
            ntpSynced = true;
            time_t now = time(nullptr);
            Serial.printf("[NTP] Synced! UTC epoch=%lu\n", (unsigned long)now);
        } else {
            // Manual time fallback
            memset(&manualTm, 0, sizeof(manualTm));
            manualTm.tm_hour  = configManager.data.manualHour;
            manualTm.tm_min   = configManager.data.manualMinute;
            manualTm.tm_mday  = configManager.data.manualDay;
            manualTm.tm_mon   = configManager.data.manualMonth - 1;
            manualTm.tm_year  = configManager.data.manualYear - 1900;
            manualTm.tm_isdst = -1;
            mktime(&manualTm);
            manualBase = millis();
            Serial.printf("[NTP] Timeout — using manual time %04d-%02d-%02d %02d:%02d\n",
                          configManager.data.manualYear,
                          configManager.data.manualMonth,
                          configManager.data.manualDay,
                          configManager.data.manualHour,
                          configManager.data.manualMinute);
        }

        Serial.println(F("[Weather] Fetching initial data..."));
        fetchWeather();
    } else {
        Serial.println(F("[Recovery] Skipping NTP + weather — recovery mode active"));
        Serial.println(F("[Recovery] Web GUI available at device IP or 192.168.4.1"));
        Serial.println(F("[Recovery] Reboot to exit recovery mode"));
    }

    lastUserActivity   = millis();
    lastNtpSync        = millis();
    lastWeatherSync    = millis();
    lastWifiRetry      = millis();
    lastDisplayRefresh = 0;   // force first draw immediately

    digitalWrite(STATUS_LED_PIN, HIGH); // LED off after boot
    Serial.println(F("[Boot] Setup complete — entering main loop"));
    Serial.printf ("[Boot] Free heap after setup: %u bytes\n", ESP.getFreeHeap());
    Serial.println(F("----------------------------------------"));
}

// ─────────────────────────────────────────────────────────────────────
// loop()
// ─────────────────────────────────────────────────────────────────────
void loop() {
    // Framework services
    WiFiManager.loop();
    updater.loop();
    configManager.loop();
    dash.loop();

    unsigned long now = millis();

    // ── Button (polled — avoids ButtonHandler static-variable bug) ──
    button.update();

    if (button.isPressed()) {
        lastUserActivity = now;
        uint32_t dur = button.getPressDuration();

        // Very long press (5 s) → reboot
        if (dur >= VERY_LONG_PRESS_MS && !longPressHandled) {
            longPressHandled = true;
            Serial.println(F("[Button] Very long press (5 s) — rebooting"));
            delay(100);
            ESP.restart();
        }
        // Long press (1 s) in normal mode → set RTC flag + soft-reset → recovery
        else if (!inRecovery && dur >= LONG_PRESS_MS && !longPressHandled) {
            longPressHandled = true;
            Serial.println(F("[Button] Long press (1 s) — entering recovery mode"));
            RTCData rtc = { RTC_MAGIC, 1 };
            ESP.rtcUserMemoryWrite(0,
                reinterpret_cast<uint32_t*>(&rtc), sizeof(rtc));
            delay(50);
            ESP.restart();
        }
    } else {
        if (longPressHandled) {
            Serial.println(F("[Button] Released"));
        }
        longPressHandled = false;
    }

    // Any open WebSocket client = someone is interacting
    if (GUI.ws.count() > 0)
        lastUserActivity = now;

    // Idle detection
    bool isIdle = (now - lastUserActivity > IDLE_TIMEOUT_MS);

    // ── Display refresh ──────────────────────────────────────────────
    if (inRecovery) {
        // Non-blocking scroll at SCROLL_FRAME_MS rate
        drawScrollText("RECOVERY", C_ORANGE);
        flushDisplay();
        delay(1); // yield to TCP/IP stack
    } else {
        unsigned long interval = isIdle ? IDLE_REFRESH_MS : ACTIVE_REFRESH_MS;
        if (now - lastDisplayRefresh >= interval) {
            lastDisplayRefresh = now;
            clearDisplay();
            struct tm* t = getTime();
            if (t) {
                drawTime(t->tm_hour, t->tm_min, C_WHITE);
                int wday = (t->tm_wday == 0) ? 7 : t->tm_wday; // 0=Sun→7
                drawInfoBars(t->tm_mday, wday);
            }
            flushDisplay();
        }
    }

    // ── Dashboard data push ──────────────────────────────────────────
    if (now - lastDashUpdate >= (unsigned long)DASH_INT_MS) {
        lastDashUpdate = now;
        updateDashboard();
    }

    // ── Periodic NTP re-sync (1 h) ───────────────────────────────────
    if (!inRecovery && now - lastNtpSync >= NTP_INTERVAL_MS) {
        lastNtpSync = now;
        Serial.println(F("[NTP] Hourly re-sync..."));
        if (timeSync.waitForSyncResult(5000) == 0) {
            if (!ntpSynced) {
                Serial.println(F("[NTP] First sync achieved on retry"));
            }
            ntpSynced = true;
            Serial.printf("[NTP] Re-sync OK  epoch=%lu\n",
                          (unsigned long)time(nullptr));
        } else {
            Serial.println(F("[NTP] Re-sync timed out"));
        }
    }

    // ── Periodic weather re-fetch (1 h) ─────────────────────────────
    if (!inRecovery && now - lastWeatherSync >= WEATHER_INT_MS) {
        lastWeatherSync = now;
        Serial.println(F("[Weather] Hourly refresh..."));
        fetchWeather();
    }

    // ── AP-mode WiFi retry (1 h) — tries reconnect if in AP mode ────
    if (!inRecovery && WiFiManager.isCaptivePortal() &&
        now - lastWifiRetry >= WIFI_RETRY_MS) {
        lastWifiRetry = now;
        Serial.println(F("[WiFi] AP mode — hourly reconnect attempt"));
        // WiFiManager will try stored credentials on next begin()
        // We trigger a soft reboot so the reconnect can succeed cleanly
        // (optional: could just call WiFiManager.setNewWifi() with stored creds,
        //  but a clean reboot is simpler and more reliable on ESP8266)
        ESP.restart();
    }

    // ── Heap watchdog (warn if < 8 kB) ──────────────────────────────
    static unsigned long lastHeapLog = 0;
    if (now - lastHeapLog >= 60000UL) {
        lastHeapLog = now;
        uint32_t heap = ESP.getFreeHeap();
        if (heap < 8192) {
            Serial.printf("[WARN] Low heap: %u bytes!\n", heap);
        } else {
            Serial.printf("[Status] Uptime=%lus  heap=%u  ntp=%d  wCode=%d  %.1f°C\n",
                          now / 1000UL, heap, ntpSynced, weatherCode, weatherTemp);
        }
    }

    // ── Status LED ───────────────────────────────────────────────────
    updateStatusLed();

    yield();
}
