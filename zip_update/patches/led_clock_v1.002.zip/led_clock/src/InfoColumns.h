// InfoColumns.h
#ifndef INFOCOLUMNS_H
#define INFOCOLUMNS_H

#include <Arduino.h>
#include <FastLED.h>
#include "LEDMatrixLayout.h"

class InfoColumns {
public:
    static void render(CRGB matrix[MATRIX_HEIGHT][MATRIX_WIDTH],
                       int day, int weekday,
                       uint32_t weatherColorPacked);

private:
    static void _bar(CRGB matrix[MATRIX_HEIGHT][MATRIX_WIDTH],
                     int col, int pixels, CRGB color);

    static CRGB _unpack(uint32_t rgb);
};

#endif // INFOCOLUMNS_H
