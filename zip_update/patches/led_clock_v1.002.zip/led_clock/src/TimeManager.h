// TimeManager.h
#ifndef TIMEMANAGER_H
#define TIMEMANAGER_H

#include <Arduino.h>
#include <time.h>

class TimeManager {
public:
    TimeManager();

    void setManualTime(int year, int month, int day,
                       int hour, int minute, int weekday);

    bool manualTimeChanged(int year, int month, int day,
                           int hour, int minute, int weekday) const;

    void getTimeComponents(int &hour, int &minute, int &second) const;
    void getDateComponents(int &year, int &month, int &day, int &weekday) const;

private:
    time_t        _manualBase;
    unsigned long _manualBaseMillis;
    bool          _manualSet;

    int  _cfgYear, _cfgMonth, _cfgDay;
    int  _cfgHour, _cfgMinute, _cfgWeekday;

    time_t _now() const;
};

#endif // TIMEMANAGER_H
