# ESP8266 LED Matrix Clock

A desk clock built on a **Wemos D1 Mini (ESP8266)** driving a **32 × 8 WS2812B LED matrix**.  
Live time (NTP), date, weekday and weather condition are shown simultaneously.  
Built on the [maakbaas/esp8266-iot-framework](https://github.com/maakbaas/esp8266-iot-framework).

---

## Hardware

| Signal         | GPIO | D1 Mini pin | Notes |
|----------------|------|-------------|-------|
| Button         | 5    | D1          | Pull-up, active LOW |
| Onboard LED    | 2    | D4          | Active LOW |
| WS2812 data    | 4    | D2          | |
| Matrix size    | —    | —           | 32 × 8 = 256 LEDs, column-snake order |
| Power          | —    | USB 5 V     | Smartphone charger, 220 V → 5 V |

### Matrix wiring
The strip starts wiring from the **bottom-right** corner of the matrix.  
Columns run physically right-to-left; the firmware mirrors column indices to
correct this. Even physical columns ascend (bottom → top), odd physical
columns descend (top → bottom).

---

## Display layout

```
Col  0- 4   Hour tens digit      (5 px wide)
Col  5      space
Col  6-10   Hour units digit     (5 px wide)
Col 11      space
Col 12      colon  ':'           (1 px wide)
Col 13      space
Col 14-18   Minute tens digit    (5 px wide)
Col 19      space
Col 20-24   Minute units digit   (5 px wide)
Col 25      gap
Col 26      DATE column          (vertical bar, bottom-up, white)
Col 27      gap
Col 28      WEEKDAY column       (vertical bar, bottom-up, cyan/orange)
Col 29      gap
Col 30      WEATHER column       (vertical bar, bottom-up, condition colour)
Col 31      trailing pad
```

All digits use a 5 × 7 pixel font (rows 0–6); row 7 is always dark.

### Info column details

| Column | Meaning | Pixels | Colour |
|--------|---------|--------|--------|
| 26 | Week-of-month | day 1-7 → 1 px, 8-14 → 2 px, … 25-31 → 5 px | White |
| 28 | Day of week | Mon=1 px … Sun=7 px | Cyan (weekday) / Orange (Sat, Sun) |
| 30 | Weather condition | Always 4 px | See table below |

### Weather colours

| OWM condition code | Condition | Colour |
|-------------------|-----------|--------|
| 800 | Clear sky | Yellow `#FFC800` |
| 801–802 | Few / scattered clouds | Pale yellow `#AAAA00` |
| 803–804 | Broken / overcast clouds | Grey `#787878` |
| 300–321 | Drizzle | Light blue `#0080FF` |
| 500–531 | Rain | Blue `#0000FF` |
| 200–232 | Thunderstorm | Purple `#8800CC` |
| 600–622 | Snow | Cyan `#00FFFF` |
| 700–781 | Fog / mist / smoke | Dim grey `#505050` |
| 0 (no data) | — | Very dim grey `#3C3C3C` |

---

## Operating modes

### Normal mode
1. Connects to saved WiFi (15 s timeout).
2. **If connected** — syncs NTP, fetches weather; refreshes display every 1 s,
   re-syncs NTP and weather every 60 minutes.
3. **If not connected** — opens AP **LED-CLOCK** (open, no password),
   clock runs on manually set time, retries WiFi every 60 minutes.
4. Onboard LED is **always OFF** in normal mode.

### Recovery mode
Entered when **any** of these occurs:
- Button held ≥ 1 s at any time (boot window or during operation)
- Crash / watchdog reset detected at boot
- RTC flag set by a runtime long-press

Behaviour in recovery mode:
- Scrolling orange **RECOVERY** text on the matrix.
- Tries saved WiFi credentials; opens AP **LED-CLOCK** if that fails.
- Full web GUI available at device IP or `192.168.4.1`
  (WiFi config, Configuration editor, OTA firmware update, Dashboard).
- NTP and weather are skipped.
- **Exit by rebooting** — press the reboot button in the web GUI or power-cycle.

### LED indicator

| State | Pattern |
|-------|---------|
| Boot window / WiFi connecting | Fast blink 100 ms |
| Normal mode | **Always OFF** |
| Recovery mode | Slow blink 1 s |
| OTA in progress | Solid ON |

### Button actions (normal mode)

| Press | Action |
|-------|--------|
| Hold ≥ 1 s | Enter recovery mode |
| Hold ≥ 5 s | Reboot immediately |

---

## First-time setup

### Prerequisites
- [VSCode](https://code.visualstudio.com/) + [PlatformIO extension](https://platformio.org/install/ide?install=vscode)
- Node.js ≥ 16 + npm (required by the framework's webpack GUI build)
- Python 3.8+ (used by PlatformIO pre-build scripts)

### 1. Install JS dependencies for the web GUI
```bash
# After the first `pio run`, the framework is downloaded into .pio/libdeps/
cd ".pio/libdeps/d1_mini/ESP8266 IoT Framework"
npm ci --legacy-peer-deps
```

### 2. Build and flash
```
PlatformIO: Build   ← generates config.h, dash.h, html.h and compiles
PlatformIO: Upload  ← flash to Wemos D1 Mini
```

> **First build note:** The `-DREBUILD_HTML` flag forces a full webpack build
> of the web GUI. This takes ~2–3 minutes on the first run. Subsequent builds
> are faster unless you change `configuration.json` or `dashboard.json`.

### 3. First configuration
1. Power on the device. It opens WiFi AP **LED-CLOCK** (no password).
2. Connect your phone/laptop to **LED-CLOCK**.
3. Open browser → `192.168.4.1`
4. Go to **Configuration** and fill in:
   - **API Key** — free OpenWeatherMap key from [openweathermap.org/api](https://openweathermap.org/api)
   - **City** — e.g. `Hong Kong`, `London`, `New York`
   - **Timezone** — POSIX TZ string, e.g.:
     - `HKT-8` (Hong Kong)
     - `CET-1CEST,M3.5.0,M10.5.0/3` (Central Europe)
     - `EST5EDT,M3.2.0,M11.1.0` (US Eastern)
5. Go to **WiFi Settings** and enter your network credentials.
6. Device reboots and connects automatically.

### Manual time (no WiFi / no NTP)
If WiFi is unavailable, set the **Manual Time Fallback** fields in the
Configuration page:
- Manual Hour / Minute / Day / Month / Year / Weekday

Save the config. The clock advances from that moment using `millis()` drift.
Accuracy is ~±1–2 s/hour.

### OTA firmware update
1. Build → `.pio/build/d1_mini/firmware.bin`
2. Open web GUI → **File Manager** → upload `firmware.bin`
3. Web GUI → **Firmware Update** → select the uploaded file → Flash

---

## Configuration reference

All settings are editable live from the web GUI at `Configuration`.

| Field | Default | Description |
|-------|---------|-------------|
| Project Name | `LED Clock` | Shown in web GUI header |
| Brightness | `5` | LED brightness 0–255 (5 ≈ 2%, suitable for desk use) |
| 24-Hour Format | `true` | Reserved for future use |
| Timezone | `HKT-8` | POSIX TZ string; see [TZ.h list](https://raw.githubusercontent.com/esp8266/Arduino/master/cores/esp8266/TZ.h) |
| API Key | *(empty)* | OpenWeatherMap free-tier API key |
| City | `Hong Kong` | City name passed to OWM API |
| Manual Hour–Weekday | `12:00 2026-01-01 Mon` | Fallback time when NTP unavailable |

---

## Serial monitor output

Connect at **115200 baud**. Example boot sequence:

```
========================================
  LED Matrix Clock — Wemos D1 Mini
  SDK: 2.2.2-dev  Core: 3.0.2
  Free heap: 47152 bytes
========================================
[Init] Button initialised on GPIO5
[Init] LittleFS mounted
[Init] Config loaded — city=Hong Kong tz=HKT-8 brightness=5
[Init] FastLED — 256 LEDs on GPIO4, brightness=5
[Boot] Reset reason: Power on  (crashFlag=0)
[Boot] Entering 3 s boot window (hold button for recovery)...
[WiFi] Connecting (timeout 15 s), AP name if needed: LED-CLOCK
[WiFi] Connected to MyNetwork
[NTP] Setting timezone: HKT-8
[NTP] Waiting for sync (10 s)...
[NTP] Synced! UTC epoch=1748000000
[Weather] Fetching for city: Hong Kong
[Weather] HTTP response code: 200
[Weather] OK  code=800  25.3°C  clear sky
[Boot] Setup complete — entering main loop
[Boot] Free heap after setup: 29840 bytes
----------------------------------------
[Status] Uptime=60s  heap=29840  ntp=1  wCode=800  25.3°C
```

Every 60 seconds a one-line status is printed. Warnings appear if free heap
drops below 8 kB.

---

## Project structure

```
led_clock/
├── platformio.ini               ← build config; lib_deps; build flags
├── .gitignore
├── README.md
├── CHANGELOG.md
├── gui/
│   └── js/
│       ├── configuration.json   ← web config fields → config.h (auto-gen)
│       └── dashboard.json       ← web dashboard fields → dash.h (auto-gen)
└── src/
    ├── main.cpp                 ← application entry, state machine, display
    ├── PinDefinitions.h         ← GPIO assignments (unchanged)
    ├── LEDMatrixLayout.h        ← mirror + snake-order mapping (unchanged)
    ├── FontData.h / .cpp        ← 5×7 pixel font data (unchanged)
    ├── ButtonHandler.h / .cpp   ← debounced button state machine (unchanged)
    ├── StatusLED.h / .cpp       ← onboard LED blink manager
    ├── TimeManager.h / .cpp     ← NTP + millis() manual time fallback
    ├── WeatherService.h / .cpp  ← OpenWeatherMap HTTP fetch + caching
    ├── DisplayManager.h / .cpp  ← FastLED matrix driver
    ├── ClockFace.h / .cpp       ← digit + scroll rendering
    └── InfoColumns.h / .cpp     ← date / weekday / weather pixel bars
```

> **Note:** `src/generated/` and `package-lock.json` are excluded from git.
> They are auto-created on the first build.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| Digits appear mirrored | Old `LEDMatrixLayout.h` | Ensure column mirror fix is present |
| Display too dim / dark | Brightness = 0 | Set brightness > 0 in Configuration |
| Weather bar not showing | API key or city missing | Fill in Configuration fields, save |
| Clock drifts after WiFi loss | Normal — millis() fallback | Set manual time in Configuration |
| Device in recovery loop | Crash on boot | Check serial monitor; fix config |
| `[NTP] Timeout` on every boot | Firewall / DNS | Verify internet access from device |

---

## Licence

GPL-3.0 — see [LICENSE](LICENSE)
