#!build
## v1.002 — Display & mirror fixes

### 修复
- 数字左右镜像翻转修正 (LEDMatrixLayout.h)
- 日期/星期/天气指示从底部行改为右侧列 (col 26/28/30, 垂直柱状)
- 默认亮度从 25 降低到 5
- 默认手动年份从 2025 改为 2026

### 改进
- Serial Monitor 增加详细启动和运行日志
- README.md 完善，新增故障排查、配置参考表格

---
<!-- 第一行控制 CI 编译行为：
     #!build    → 正常编译并发布 Release
     #!no-build → 跳过编译（仅推送代码）
-->
