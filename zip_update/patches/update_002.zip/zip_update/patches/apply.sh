#!/usr/bin/env bash
# apply.sh — post-extraction sanity check
set -euo pipefail
echo "=== apply.sh ==="
mkdir -p zip_update/patches
touch zip_update/applied_patches.txt
for f in platformio.ini src/main.cpp LEDMatrixLayout.h \
          gui/js/configuration.json gui/js/dashboard.json gui/js/index.js; do
  [ -f "$f" ] && echo "  ✓ $f" || echo "  ✗ MISSING: $f"
done
echo "=== done ==="
