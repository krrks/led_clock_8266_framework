#!/usr/bin/env bash
# apply.sh — runs after zip extraction in CI
set -euo pipefail

echo "=== apply.sh start ==="

# ── 1. Ensure zip_update directories exist ────────────────────────
mkdir -p zip_update/patches

# ── 2. Ensure applied_patches.txt exists ─────────────────────────
touch zip_update/applied_patches.txt

# ── 3. Sanity-check that required source files are present ────────
for f in src/main.cpp LEDMatrixLayout.h \
          gui/js/configuration.json gui/js/dashboard.json \
          gui/js/index.js platformio.ini; do
    if [ ! -f "$f" ]; then
        echo "WARNING: expected file not found: $f"
    else
        echo "  ✓ $f"
    fi
done

echo "=== apply.sh done ==="
